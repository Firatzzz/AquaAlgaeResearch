﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Aplikasi_Reasearch_Alga
{
    public partial class Form1 : Form
    {
        SerialPort serialPort;

        Panel panelO2, panelCO2, panelPM, panelCO;
        Label labelO2, labelCO2, labelPM, labelCO;

        Panel panelStatusO2, panelStatusCO2, panelStatusPM, panelStatusCO;
        Label labelStatusO2, labelStatusCO2, labelStatusPM, labelStatusCO;

        public Form1()
        {
            InitializeComponent();

            InitializeCharts(); // Inisialisasi grafik

            // Ganti judul dan style groupbox
            groupBox1.Text = "Data Sensor";
            groupBox2.Text = "Status Sensor";
            groupBox1.BackColor = Color.MediumSeaGreen;
            groupBox2.BackColor = Color.MediumSeaGreen;

            // Atur font GroupBox agar tidak tertutup panel
            groupBox1.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            groupBox2.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            InitializeSensorPanels();
            InitializeStatusPanels();

            // Serial port init
            serialPort = new SerialPort("COM3", 9600);
            serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            try
            {
                serialPort.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal membuka serial port: " + ex.Message);
            }
        }

        private void chart1_Click(object sender, EventArgs e) { }
        private void chart2_Click(object sender, EventArgs e) { }

        private void InitializeSensorPanels()
        {
            int marginTop = 30;

            panelO2 = CreateSensorPanel(out labelO2, "Oksigen : --");
            panelO2.Location = new Point(10, marginTop);
            groupBox1.Controls.Add(panelO2);

            panelCO2 = CreateSensorPanel(out labelCO2, "CO2     : --");
            panelCO2.Location = new Point(10, panelO2.Bottom + 10);
            groupBox1.Controls.Add(panelCO2);

            panelPM = CreateSensorPanel(out labelPM, "PM      : --");
            panelPM.Location = new Point(10, panelCO2.Bottom + 10);
            groupBox1.Controls.Add(panelPM);

            panelCO = CreateSensorPanel(out labelCO, "CO      : --");
            panelCO.Location = new Point(10, panelPM.Bottom + 10);
            groupBox1.Controls.Add(panelCO);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Menggunakan SaveFileDialog untuk memilih lokasi dan nama file
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV Files (*.csv)|*.csv";
            saveFileDialog.DefaultExt = "csv";
            saveFileDialog.AddExtension = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;
                SaveDataToCSV(filePath);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void InitializeStatusPanels()
        {
            int marginTop = 30;

            panelStatusO2 = CreateSensorPanel(out labelStatusO2, "Status Oksigen : --");
            panelStatusO2.Location = new Point(10, marginTop);
            groupBox2.Controls.Add(panelStatusO2);

            panelStatusCO2 = CreateSensorPanel(out labelStatusCO2, "Status CO2     : --");
            panelStatusCO2.Location = new Point(10, panelStatusO2.Bottom + 10);
            groupBox2.Controls.Add(panelStatusCO2);

            panelStatusPM = CreateSensorPanel(out labelStatusPM, "Status PM      : --");
            panelStatusPM.Location = new Point(10, panelStatusCO2.Bottom + 10);
            groupBox2.Controls.Add(panelStatusPM);

            panelStatusCO = CreateSensorPanel(out labelStatusCO, "Status CO      : --");
            panelStatusCO.Location = new Point(10, panelStatusPM.Bottom + 10);
            groupBox2.Controls.Add(panelStatusCO);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private Panel CreateSensorPanel(out Label label, string defaultText)
        {
            Panel panel = new Panel
            {
                Size = new Size(200, 30),
                BackColor = Color.White,
                BorderStyle = BorderStyle.None
            };

            label = new Label
            {
                AutoSize = false,
                Text = defaultText,
                Font = new Font("Segoe UI", 9, FontStyle.Bold), // Menggunakan font bold
                ForeColor = Color.Black,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(4, 6, 0, 0)
            };

            panel.Controls.Add(label);
            return panel;
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = serialPort.ReadLine();
                this.BeginInvoke(new Action(() =>
                {
                    TampilkanDataSensor(data);
                }));
            }
            catch (Exception) { }
        }

        private void TampilkanDataSensor(string data)
        {
            // Format dari Arduino: O2:20.5|CO2:450|PM:80|CO:12
            string[] parts = data.Split('|');

            foreach (var part in parts)
            {
                var keyValue = part.Split(':');
                if (keyValue.Length != 2) continue;

                string label = keyValue[0].Trim();
                if (!float.TryParse(keyValue[1], out float value)) continue;

                switch (label)
                {
                    case "O2":
                        labelO2.Text = $"Oksigen : {value} %";
                        labelStatusO2.Text = $"Status Oksigen : {(value < 19.5 ? "Rendah" : "Normal")}"; // Status berdasarkan nilai
                        // Menambahkan data ke chart1 (Oksigen)
                        chart1.Series["Oxygen"].Points.AddY(value);
                        break;
                    case "CO2":
                        labelCO2.Text = $"CO2     : {value} ppm";
                        labelStatusCO2.Text = $"Status CO2     : {(value > 1000 ? "Tinggi" : "Normal")}";
                        // Menambahkan data ke chart1 (CO2)
                        chart1.Series["CO2"].Points.AddY(value);
                        break;
                    case "PM":
                        labelPM.Text = $"PM      : {value} µg/m³";
                        labelStatusPM.Text = $"Status PM      : {(value > 150 ? "Berbahaya" : "Aman")}";
                        // Menambahkan data ke chart2 (PM)
                        chart2.Series["PM"].Points.AddY(value);
                        break;
                    case "CO":
                        labelCO.Text = $"CO      : {value} ppm";
                        labelStatusCO.Text = $"Status CO      : {(value > 50 ? "Berbahaya" : "Aman")}";
                        // Menambahkan data ke chart2 (CO)
                        chart2.Series["CO"].Points.AddY(value);
                        break;
                }
            }
        }

        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        private void InitializeCharts()
        {
            // Inisialisasi series pada chart1
            chart1.Series.Clear();
            chart1.Series.Add("Oxygen");
            chart1.Series["Oxygen"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series["Oxygen"].BorderWidth = 2;

            chart1.Series.Add("CO2");
            chart1.Series["CO2"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series["CO2"].BorderWidth = 2;

            // Inisialisasi series pada chart2
            chart2.Series.Clear();
            chart2.Series.Add("PM");
            chart2.Series["PM"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["PM"].BorderWidth = 2;

            chart2.Series.Add("CO");
            chart2.Series["CO"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["CO"].BorderWidth = 2;
        }

        // Fungsi untuk menyimpan data sensor ke CSV
        private void SaveDataToCSV(string filePath)
        {
            // Menyiapkan file CSV dan menulis header jika belum ada
            StringBuilder csvContent = new StringBuilder();

            if (!File.Exists(filePath))
            {
                csvContent.AppendLine("Timestamp,O2 (%),CO2 (ppm),PM (µg/m³),CO (ppm)");
            }

            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string dataLine = $"{timestamp},{labelO2.Text.Split(':')[1].Trim()},{labelCO2.Text.Split(':')[1].Trim()},{labelPM.Text.Split(':')[1].Trim()},{labelCO.Text.Split(':')[1].Trim()}";

            csvContent.AppendLine(dataLine);

            // Menyimpan ke file
            File.AppendAllText(filePath, csvContent.ToString());
            MessageBox.Show("Data berhasil disimpan ke CSV.");
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void pictureBox2_Click(object sender, EventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void groupBox3_Enter(object sender, EventArgs e) { }
    }
}
