﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Reasearch_Alga
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.Controls.Clear(); // Hapus kontrol lama jika ada
            SetupLoginForm();
        }

        private void SetupLoginForm()
        {
            this.Text = "Login";
            this.WindowState = FormWindowState.Normal; // Pastikan normal, bukan maximized
            this.StartPosition = FormStartPosition.CenterScreen; // Form muncul di tengah
            this.Size = new Size(600, 400); // Ukuran form
            this.BackColor = Color.MediumSeaGreen;

            int formWidth = this.ClientSize.Width;
            int formHeight = this.ClientSize.Height;

            // Label Judul
            Label labelTitle = new Label();
            labelTitle.Text = "DASHBOARD RESEARCH ALGA";
            labelTitle.Font = new Font("Segoe UI Semibold", 20, FontStyle.Bold);
            labelTitle.AutoSize = true;
            labelTitle.ForeColor = Color.DarkSlateGray;
            labelTitle.Location = new Point((formWidth - labelTitle.PreferredWidth) / 2, 30);
            this.Controls.Add(labelTitle);

            // Label Username
            Label labelUsername = new Label();
            labelUsername.Text = "Username";
            labelUsername.Font = new Font("Segoe UI", 12);
            labelUsername.AutoSize = true;
            labelUsername.Location = new Point(100, 100);
            this.Controls.Add(labelUsername);

            // TextBox Username
            TextBox textBoxUsername = new TextBox();
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Font = new Font("Segoe UI", 12);
            textBoxUsername.Size = new Size(250, 30);
            textBoxUsername.Location = new Point(200, 100);
            this.Controls.Add(textBoxUsername);

            // Label Password
            Label labelPassword = new Label();
            labelPassword.Text = "Password";
            labelPassword.Font = new Font("Segoe UI", 12);
            labelPassword.AutoSize = true;
            labelPassword.Location = new Point(100, 150);
            this.Controls.Add(labelPassword);

            // TextBox Password
            TextBox textBoxPassword = new TextBox();
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Font = new Font("Segoe UI", 12);
            textBoxPassword.Size = new Size(250, 30);
            textBoxPassword.Location = new Point(200, 150);
            textBoxPassword.PasswordChar = '*';
            this.Controls.Add(textBoxPassword);

            // Button Login
            Button buttonLogin = new Button();
            buttonLogin.Text = "Login";
            buttonLogin.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            buttonLogin.Size = new Size(250, 35);
            buttonLogin.Location = new Point(200, 200);
            buttonLogin.BackColor = Color.White;
            buttonLogin.FlatStyle = FlatStyle.Flat;
            buttonLogin.Click += button1_Click;
            this.Controls.Add(buttonLogin);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = this.Controls["textBoxUsername"].Text;
            string password = this.Controls["textBoxPassword"].Text;

            if (username == "admin" && password == "1234")
            {
                MessageBox.Show("Login Berhasil!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Menutup Form2 dan membuka Form1
                Form1 dashboard = new Form1(); // pastikan Form1 sudah ada
                dashboard.Show();
                this.Hide(); // Menyembunyikan Form2
            }
            else
            {
                MessageBox.Show("Username atau Password salah!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
