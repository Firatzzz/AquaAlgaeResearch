﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Aplikasi_Reasearch_Algaa; // <-- Tambahkan baris ini

namespace EnhancedLoginApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            CenterControls(); // Panggil fungsi untuk menengahkan kontrol saat inisialisasi
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Please enter both username and password.", "Login Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // --- PERUBAHAN DIMULAI DI SINI ---

            // Tampilkan pesan sukses (opsional, bisa dihapus)
            MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Buat instance Form2
            Form2 form2 = new Form2();
            // Sembunyikan form login saat ini
            this.Hide();
            // Tampilkan Form2
            form2.Show();

            // --- PERUBAHAN SELESAI DI SINI ---
        }

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, 0xA1, 0x2, 0);
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginForm_Paint(object sender, PaintEventArgs e)
        {
            // Tidak ada perubahan
        }

        private void CenterControls()
        {
            int centerX = this.Width / 2;

            // Tengahkan kontrol input dan tombol
            txtUsername.Left = centerX - (txtUsername.Width / 2);
            txtPassword.Left = centerX - (txtPassword.Width / 2);
            lblUsername.Left = txtUsername.Left;
            lblPassword.Left = txtPassword.Left;
            btnLogin.Left = centerX - (btnLogin.Width / 2);
        }

        private void LoginForm_Resize(object sender, EventArgs e)
        {
            btnMinimize.Location = new Point(this.Width - 70, 5);
            btnClose.Location = new Point(this.Width - 35, 5);
            CenterControls(); // Panggil fungsi untuk menengahkan kontrol saat resize
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
            // Tidak ada aksi
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            CenterControls(); // Pastikan posisi tengah saat form pertama kali dimuat
        }
    }
}