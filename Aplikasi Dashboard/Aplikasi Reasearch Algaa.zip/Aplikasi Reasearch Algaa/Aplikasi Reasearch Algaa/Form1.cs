﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

// You'll need to add a reference to your Form2's namespace
using Aplikasi_Reasearch_Algaa;

namespace EnhancedLoginApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Please enter both username and password.", "Login Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Here you would add your authentication logic
            MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // After successful login, open Form2 and hide the login form
            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();
        }

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // Release capture if already capturing
                if (pnlHeader.Capture) pnlHeader.Capture = false;
                // Start capturing the mouse
                pnlHeader.Capture = true;
                // Create a message to the window to drag it
                Message msg = Message.Create(this.Handle, 0xA1, new IntPtr(2), IntPtr.Zero);
                this.WndProc(ref msg);
                // Release the mouse capture
                pnlHeader.Capture = false;
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginForm_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            // Draw border
            using (Pen pen = new Pen(Color.FromArgb(40, 0, 0, 0), 1))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, this.Width - 1, this.Height - 1);
            }
        }

        private void LoginForm_Resize(object sender, EventArgs e)
        {
            btnMinimize.Location = new Point(this.Width - 70, 5);
            btnClose.Location = new Point(this.Width - 35, 5);
            int centerX = this.Width / 2;
            txtUsername.Left = centerX - (txtUsername.Width / 2);
            txtPassword.Left = centerX - (txtPassword.Width / 2);
            lblUsername.Left = txtUsername.Left;
            lblPassword.Left = txtPassword.Left;
            btnLogin.Left = centerX - (btnLogin.Width / 2);
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
        }
    }
}
