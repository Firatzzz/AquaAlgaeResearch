﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;

namespace Aplikasi_Reasearch_Algaa
{
    public partial class Form2 : Form
    {
        private SerialPort serialPort;
        private List<string> logData = new List<string>();
        private const int MAX_LOG_LINES = 100;

        // Current sensor values
        private double o2Value = 0;
        private double co2Value = 0;
        private double pmValue = 0;
        private double coValue = 0;

        // UI Controls
        private ComboBox portComboBox;
        private Button connectButton;
        private TextBox logTextBox;
        private Label[] valueLabels = new Label[4];

        public Form2()
        {
            InitializeComponent();
            SetupUI();
            LoadSerialPorts();
        }

        // Note: We don't define InitializeComponent() here since it's already defined in Form2.Designer.cs

        private void SetupUI()
        {
            // Main layout
            TableLayoutPanel mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(10),
                BackColor = Color.Teal
            };

            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            // Top control panel
            Panel controlPanel = CreateControlPanel();
            mainLayout.Controls.Add(controlPanel, 0, 0);

            // Sensor display panel
            Panel sensorPanel = CreateSensorPanel();
            mainLayout.Controls.Add(sensorPanel, 0, 1);

            // Log panel
            Panel logPanel = CreateLogPanel();
            mainLayout.Controls.Add(logPanel, 0, 2);

            this.Controls.Add(mainLayout);

            // Set up serial port
            serialPort = new SerialPort();
            serialPort.DataReceived += SerialPort_DataReceived;
        }

        private Panel CreateControlPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.WhiteSmoke
            };

            // Port selection
            portComboBox = new ComboBox
            {
                Location = new Point(10, 10),
                Width = 100,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            panel.Controls.Add(portComboBox);

            // Baud rate selection
            ComboBox baudComboBox = new ComboBox
            {
                Location = new Point(120, 10),
                Width = 80,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            baudComboBox.Items.AddRange(new object[] { "9600", "19200", "38400", "57600", "115200" });
            baudComboBox.SelectedIndex = 0;
            panel.Controls.Add(baudComboBox);

            // Connect button
            connectButton = new Button
            {
                Text = "Connect",
                Location = new Point(210, 9),
                Width = 80,
                Height = 25
            };
            connectButton.Click += (s, e) => ToggleConnection();
            panel.Controls.Add(connectButton);

            // Clear button
            Button clearButton = new Button
            {
                Text = "Clear",
                Location = new Point(300, 9),
                Width = 70,
                Height = 25
            };
            clearButton.Click += (s, e) => ClearData();
            panel.Controls.Add(clearButton);

            // Export button
            Button exportButton = new Button
            {
                Text = "Export",
                Location = new Point(380, 9),
                Width = 80,
                Height = 25
            };
            exportButton.Click += (s, e) => ExportData();
            panel.Controls.Add(exportButton);

            return panel;
        }

        private Panel CreateSensorPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.AliceBlue,
                Padding = new Padding(10)
            };

            // Sensor values table
            TableLayoutPanel sensorTable = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 2
            };

            for (int i = 0; i < 4; i++)
            {
                sensorTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            // Sensor names and units
            string[] sensorNames = { "O₂", "CO₂", "PM", "CO" };
            string[] sensorUnits = { "%", "PPM", "μg/m³", "PPM" };
            Color[] sensorColors = {
                Color.RoyalBlue,
                Color.ForestGreen,
                Color.DarkOrange,
                Color.Firebrick
            };

            for (int i = 0; i < 4; i++)
            {
                // Create sensor name label
                Label nameLabel = new Label
                {
                    Text = $"{sensorNames[i]} ({sensorUnits[i]})",
                    TextAlign = ContentAlignment.MiddleCenter,
                    Dock = DockStyle.Fill,
                    Font = new Font("Segoe UI", 9)
                };
                sensorTable.Controls.Add(nameLabel, i, 0);

                // Create value label
                valueLabels[i] = new Label
                {
                    Text = "0.00",
                    TextAlign = ContentAlignment.MiddleCenter,
                    Dock = DockStyle.Fill,
                    Font = new Font("Segoe UI", 14, FontStyle.Bold),
                    ForeColor = sensorColors[i]
                };
                sensorTable.Controls.Add(valueLabels[i], i, 1);
            }

            panel.Controls.Add(sensorTable);
            return panel;
        }

        private Panel CreateLogPanel()
        {
            Panel panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(0, 5, 0, 0)
            };

            // Label
            Label logLabel = new Label
            {
                Text = "Serial Monitor Data",
                Dock = DockStyle.Top,
                Height = 20,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            panel.Controls.Add(logLabel);

            // Log textbox
            logTextBox = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor = Color.WhiteSmoke,
                Font = new Font("Consolas", 9),
                ReadOnly = true
            };
            panel.Controls.Add(logTextBox);

            return panel;
        }

        private void LoadSerialPorts()
        {
            string[] ports = SerialPort.GetPortNames();
            portComboBox.Items.Clear();
            portComboBox.Items.AddRange(ports);
            if (ports.Length > 0)
                portComboBox.SelectedIndex = 0;
        }

        private void ToggleConnection()
        {
            if (serialPort.IsOpen)
            {
                // Disconnect
                try
                {
                    serialPort.Close();
                    connectButton.Text = "Connect";
                    portComboBox.Enabled = true;
                    AppendToLog("Disconnected from serial port");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error closing port: " + ex.Message);
                }
            }
            else
            {
                // Connect
                try
                {
                    if (portComboBox.SelectedItem == null)
                    {
                        MessageBox.Show("Please select a COM port");
                        return;
                    }

                    serialPort.PortName = portComboBox.SelectedItem.ToString();
                    serialPort.BaudRate = 9600; // Default to 9600
                    serialPort.Open();

                    connectButton.Text = "Disconnect";
                    portComboBox.Enabled = false;
                    AppendToLog("Connected to " + serialPort.PortName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error opening port: " + ex.Message);
                }
            }
        }

        private void ClearData()
        {
            logData.Clear();
            logTextBox.Clear();

            // Reset values
            for (int i = 0; i < 4; i++)
            {
                valueLabels[i].Text = "0.00";
            }

            o2Value = 0;
            co2Value = 0;
            pmValue = 0;
            coValue = 0;

            AppendToLog("Log and values cleared");
        }

        private void ExportData()
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "CSV Files (*.csv)|*.csv|Text Files (*.txt)|*.txt",
                    Title = "Export Data"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        // Write header based on file type
                        if (saveFileDialog.FileName.EndsWith(".csv"))
                        {
                            writer.WriteLine("Timestamp,Type,Value,Unit");

                            // Write each data point
                            foreach (string line in logData)
                            {
                                if (line.Contains("Nilai"))
                                {
                                    string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                                    if (line.Contains("[") && line.Contains("]"))
                                    {
                                        string timeStr = line.Substring(1, line.IndexOf("]") - 1);
                                        if (DateTime.TryParse(timeStr, out DateTime parsedTime))
                                        {
                                            timestamp = parsedTime.ToString("yyyy-MM-dd HH:mm:ss");
                                        }
                                    }

                                    if (line.Contains("Nilai O2"))
                                        ExtractAndWriteData(writer, line, "O2", "%", timestamp);
                                    else if (line.Contains("Nilai CO2"))
                                        ExtractAndWriteData(writer, line, "CO2", "PPM", timestamp);
                                    else if (line.Contains("Nilai PM"))
                                        ExtractAndWriteData(writer, line, "PM", "μg/m³", timestamp);
                                    else if (line.Contains("Nilai CO"))
                                        ExtractAndWriteData(writer, line, "CO", "PPM", timestamp);
                                }
                            }
                        }
                        else
                        {
                            // Text format - write summary and log
                            writer.WriteLine("--- ALGA RESEARCH MONITOR DATA ---");
                            writer.WriteLine($"Date: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                            writer.WriteLine($"O2 Level: {o2Value:F2} %");
                            writer.WriteLine($"CO2 Level: {co2Value:F0} PPM");
                            writer.WriteLine($"PM Level: {pmValue:F0} μg/m³");
                            writer.WriteLine($"CO Level: {coValue:F0} PPM");
                            writer.WriteLine("--- LOG DATA ---");

                            foreach (string line in logData)
                            {
                                writer.WriteLine(line);
                            }
                        }
                    }

                    AppendToLog($"Data exported to {saveFileDialog.FileName}");
                    MessageBox.Show("Data exported successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting data: " + ex.Message);
            }
        }

        private void ExtractAndWriteData(StreamWriter writer, string line, string type, string unit, string timestamp)
        {
            string[] parts = line.Split(':');
            if (parts.Length >= 2)
            {
                string valueStr = parts[1].Trim()
                    .Replace(" %", "")
                    .Replace(" PPM", "")
                    .Replace(" ug/m3", "");

                if (valueStr.Contains("<400")) valueStr = "400";
                writer.WriteLine($"{timestamp},{type},{valueStr},{unit}");
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (!serialPort.IsOpen) return;

            try
            {
                string data = serialPort.ReadLine();
                this.BeginInvoke(new Action(() => ProcessSerialData(data)));
            }
            catch (Exception)
            {
                // Handle error silently
            }
        }

        private void ProcessSerialData(string data)
        {
            try
            {
                // Add timestamp and data to log
                string timestamp = DateTime.Now.ToString("HH:mm:ss");
                string logLine = $"[{timestamp}] {data}";
                AppendToLog(logLine);

                // Parse sensor data
                if (data.Contains("Nilai O2"))
                {
                    ParseSensorData(data, "O2", ref o2Value, 0, "F2");
                }
                else if (data.Contains("Nilai CO2"))
                {
                    string[] parts = data.Split(':');
                    if (parts.Length >= 2)
                    {
                        string valueStr = parts[1].Trim();
                        if (valueStr.Contains("<400"))
                            valueStr = "400";

                        if (double.TryParse(valueStr, out double value))
                        {
                            co2Value = value;
                            UpdateValueDisplay(1, value.ToString("F0"));
                        }
                    }
                }
                else if (data.Contains("Nilai PM"))
                {
                    ParseSensorData(data, "PM", ref pmValue, 2, "F0", " ug/m3");
                }
                else if (data.Contains("Nilai CO"))
                {
                    ParseSensorData(data, "CO", ref coValue, 3, "F0", " PPM");
                }
            }
            catch (Exception ex)
            {
                AppendToLog($"Error: {ex.Message}");
            }
        }

        private void ParseSensorData(string data, string sensorType, ref double value, int displayIndex, string format, string unitSuffix = " %")
        {
            string[] parts = data.Split(':');
            if (parts.Length >= 2)
            {
                string valueStr = parts[1].Trim().Replace(unitSuffix, "");

                if (double.TryParse(valueStr, out double parsedValue))
                {
                    value = parsedValue;
                    UpdateValueDisplay(displayIndex, parsedValue.ToString(format));
                }
            }
        }

        private void UpdateValueDisplay(int index, string value)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(() => UpdateValueDisplay(index, value)));
                return;
            }

            valueLabels[index].Text = value;
        }

        private void AppendToLog(string text)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action(() => AppendToLog(text)));
                return;
            }

            // Add to data list and limit size
            logData.Add(text);
            if (logData.Count > MAX_LOG_LINES)
                logData.RemoveAt(0);

            // Update textbox
            StringBuilder sb = new StringBuilder();
            foreach (string line in logData)
            {
                sb.AppendLine(line);
            }
            logTextBox.Text = sb.ToString();

            // Scroll to end
            logTextBox.SelectionStart = logTextBox.Text.Length;
            logTextBox.ScrollToCaret();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
            }
            base.OnFormClosing(e);
        }
    }

    // Remove the Program class since your project already has a Program.cs file
    // with the Main method defined
}