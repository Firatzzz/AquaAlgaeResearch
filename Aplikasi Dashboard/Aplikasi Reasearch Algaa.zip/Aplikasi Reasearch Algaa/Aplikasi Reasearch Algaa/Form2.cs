﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using System.Globalization;
using System.Windows.Forms.DataVisualization.Charting;
using System.Linq;
using System.Text;

namespace Aplikasi_Reasearch_Algaa
{
    // --- Custom Panel dengan Sudut Membulat ---
    public class RoundedPanel : Panel
    {
        public int CornerRadius { get; set; } = 10;
        public Color BorderColor { get; set; } = Color.FromArgb(80, 80, 80);
        public float BorderThickness { get; set; } = 1.0f;

        public RoundedPanel()
        {
            this.BorderStyle = BorderStyle.None;
            this.DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = this.ClientRectangle;
            using (GraphicsPath path = GetRoundedPath(rect, CornerRadius))
            {
                this.Region = new Region(path);
                using (SolidBrush brush = new SolidBrush(this.BackColor))
                {
                    e.Graphics.FillPath(brush, path);
                }
                if (BorderThickness > 0)
                {
                    Rectangle borderRect = new Rectangle(rect.X, rect.Y, rect.Width - (int)Math.Ceiling(BorderThickness), rect.Height - (int)Math.Ceiling(BorderThickness));
                    using (GraphicsPath borderPath = GetRoundedPath(borderRect, CornerRadius))
                    using (Pen pen = new Pen(BorderColor, BorderThickness))
                    {
                        e.Graphics.DrawPath(pen, borderPath);
                    }
                }
            }
        }

        private GraphicsPath GetRoundedPath(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0) { path.AddRectangle(bounds); return path; }
            int diameter = radius * 2;
            Rectangle arc = new Rectangle(bounds.Location, new Size(diameter, diameter));
            path.AddArc(arc, 180, 90); path.AddArc(new Rectangle(bounds.Right - diameter, bounds.Y, diameter, diameter), 270, 90);
            path.AddArc(new Rectangle(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter), 0, 90);
            path.AddArc(new Rectangle(bounds.Left, bounds.Bottom - diameter, diameter, diameter), 90, 90);
            path.CloseFigure(); return path;
        }
    }

    // --- Custom Button dengan Sudut Membulat ---
    public class RoundedButton : Button
    {
        public int CornerRadius { get; set; } = 15;
        public RoundedButton()
        {
            this.FlatStyle = FlatStyle.Flat; this.FlatAppearance.BorderSize = 0;
            this.BackColor = Color.FromArgb(0, 122, 204); this.ForeColor = Color.White;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Bold); this.Cursor = Cursors.Hand; this.Height = 35;
        }
        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent); pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, this.Width, this.Height); int radius = CornerRadius;
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90); path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90); path.CloseFigure(); this.Region = new Region(path);
            }
        }
    }

    // --- Struktur untuk menyimpan data ---
    public struct SensorReading
    {
        public DateTime Timestamp; public double O2; public double CO2; public double PM; public double CO;
        public override string ToString() { return $"{Timestamp:yyyy-MM-dd HH:mm:ss},{O2:F2},{CO2:F0},{PM:F0},{CO:F0}"; }
    }

    public partial class Form2 : Form
    {
        // --- Warna Tema Gelap ---
        private readonly Color bgColor = Color.FromArgb(30, 30, 30);
        private readonly Color cardColor = Color.FromArgb(45, 45, 45);
        private readonly Color textColor = Color.FromArgb(240, 240, 240);
        private readonly Color grayColor = Color.FromArgb(160, 160, 160);
        private readonly Color accentColor = Color.FromArgb(0, 122, 204);
        private readonly Color saveButtonColor = Color.FromArgb(40, 167, 69);
        private readonly Color disconnectColor = Color.OrangeRed;
        private readonly Color chartGridColor = Color.FromArgb(60, 60, 60);

        // --- Variabel lain ---
        private readonly string[] titles = { "O2 – Oxygen Level", "CO₂ – Carbon Dioxide", "PM – Particulate Matter", "CO – Carbon Monoxide" };
        private readonly string[] units = { "%", "PPM", "μg/m³", "PPM" };
        private readonly double[] sparklineMin = { 18, 300, 0, 0 };
        private readonly double[] sparklineMax = { 23, 1500, 80, 30 };
        private const int MAX_SPARKLINE_POINTS = 50;
        private SerialPort serialPort;
        private double[] currentValues = new double[4];
        private Label[] valueLabels = new Label[4];
        private Chart[] sparklineCharts = new Chart[4];
        private ComboBox portComboBox;
        private RoundedButton connectButton;
        private RoundedButton saveButton;
        private List<SensorReading> historicalData = new List<SensorReading>();
        private SensorReading lastReading;

        public Form2()
        {
            InitializeComponent(); SetupFormStyle(); SetupUI(); LoadSerialPorts(); SetupAllCharts(); lastReading = new SensorReading { Timestamp = DateTime.Now };
        }
        private void SetupFormStyle()
        {
            this.Text = "AquaAlgae Research Dashboard"; // <-- Ubah judul window
            this.Size = new Size(800, 600); // <-- Sedikit perbesar agar judul muat
            this.MinimumSize = new Size(700, 500);
            this.BackColor = bgColor; this.ForeColor = textColor; this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = FormBorderStyle.Sizable; this.MaximizeBox = true; this.MinimizeBox = true;
        }
        private void SetupUI()
        {
            TableLayoutPanel mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3, BackColor = bgColor, Padding = new Padding(15) };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60)); mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50)); mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            Panel titleBar = CreateTopBarPanel(); mainLayout.Controls.Add(titleBar, 0, 0); mainLayout.SetColumnSpan(titleBar, 2);
            mainLayout.Controls.Add(CreateDataCardPanel(titles[0], "0.00", 0), 0, 1); mainLayout.Controls.Add(CreateDataCardPanel(titles[1], "0", 1), 1, 1);
            mainLayout.Controls.Add(CreateDataCardPanel(titles[2], "0", 2), 0, 2); mainLayout.Controls.Add(CreateDataCardPanel(titles[3], "0", 3), 1, 2);
            this.Controls.Add(mainLayout); serialPort = new SerialPort(); serialPort.DataReceived += SerialPort_DataReceived;
        }

        // --- METODE YANG DIPERBARUI UNTUK JUDUL ---
        private Panel CreateTopBarPanel()
        {
            Panel panel = new Panel { Dock = DockStyle.Fill, BackColor = bgColor, Padding = new Padding(10) };

            // Panel Kiri untuk Judul & Sub-judul
            FlowLayoutPanel titlePanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Left,
                FlowDirection = FlowDirection.TopDown,
                AutoSize = true,
                BackColor = Color.Transparent,
                WrapContents = false
            };

            Label mainTitleLabel = new Label
            {
                Text = "AquaAlgae Research", // <-- Judul Baru
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = textColor,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 0)
            };

            Label subTitleLabel = new Label
            {
                Text = "UPNVJ Teknik Elektro", // <-- Sub-judul
                Font = new Font("Segoe UI", 8F, FontStyle.Regular),
                ForeColor = grayColor,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 0)
            };

            titlePanel.Controls.Add(mainTitleLabel);
            titlePanel.Controls.Add(subTitleLabel);

            // Panel Kanan untuk Kontrol
            FlowLayoutPanel rightControls = new FlowLayoutPanel { Dock = DockStyle.Right, FlowDirection = FlowDirection.RightToLeft, AutoSize = true, BackColor = Color.Transparent, WrapContents = false };
            connectButton = new RoundedButton { Text = "Connect", Width = 110, CornerRadius = 17, Margin = new Padding(5, 0, 0, 0), BackColor = accentColor }; connectButton.Click += (s, e) => ToggleConnection();
            saveButton = new RoundedButton { Text = "Save CSV", Width = 110, CornerRadius = 17, BackColor = saveButtonColor, Margin = new Padding(5, 0, 5, 0) }; saveButton.Click += (s, e) => ExportToCsv();
            portComboBox = new ComboBox { Width = 100, Height = 35, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F), BackColor = Color.FromArgb(60, 60, 60), ForeColor = textColor, FlatStyle = FlatStyle.Flat, Margin = new Padding(5, 5, 5, 5) };

            rightControls.Controls.Add(connectButton);
            rightControls.Controls.Add(saveButton);
            rightControls.Controls.Add(portComboBox);

            // Tambahkan Panel Kiri dan Kanan
            panel.Controls.Add(titlePanel);
            panel.Controls.Add(rightControls);
            rightControls.BringToFront();
            return panel;
        }

        private Panel CreateDataCardPanel(string title, string initialValue, int index)
        {
            RoundedPanel card = new RoundedPanel { BackColor = cardColor, BorderColor = Color.FromArgb(80, 80, 80), Margin = new Padding(10), Padding = new Padding(15), Dock = DockStyle.Fill };
            TableLayoutPanel cardContent = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Color.Transparent };
            cardContent.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); cardContent.RowStyles.Add(new RowStyle(SizeType.Absolute, 60)); cardContent.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Label titleLabel = new Label { Text = title, Font = new Font("Segoe UI", 10F), ForeColor = grayColor, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent };
            valueLabels[index] = new Label { Text = $"{initialValue} {units[index]}", Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold), ForeColor = textColor, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.Transparent };
            sparklineCharts[index] = new Chart { Dock = DockStyle.Fill, BackColor = cardColor, Margin = new Padding(0, 10, 0, 0), BorderlineDashStyle = ChartDashStyle.NotSet, BorderlineWidth = 0 };
            cardContent.Controls.Add(titleLabel, 0, 0); cardContent.Controls.Add(valueLabels[index], 0, 1); cardContent.Controls.Add(sparklineCharts[index], 0, 2);
            card.Controls.Add(cardContent); return card;
        }
        private void SetupAllCharts() { for (int i = 0; i < 4; i++) { SetupSparklineChart(sparklineCharts[i], accentColor, sparklineMin[i], sparklineMax[i]); } }

        private void SetupSparklineChart(Chart chart, Color color, double min, double max)
        {
            chart.Series.Clear(); chart.ChartAreas.Clear(); chart.Legends.Clear();
            chart.BorderlineDashStyle = ChartDashStyle.NotSet;
            chart.BorderlineWidth = 0;
            chart.BackColor = cardColor;
            chart.BorderSkin.SkinStyle = BorderSkinStyle.None;

            ChartArea ca = new ChartArea("SparkArea")
            {
                BackColor = cardColor,
                BorderWidth = 0,
                BorderDashStyle = ChartDashStyle.NotSet,
                BorderColor = Color.Transparent
            };

            ca.AxisX.Enabled = AxisEnabled.False;
            ca.AxisY.Enabled = AxisEnabled.False;
            ca.AxisX.LineColor = Color.Transparent;
            ca.AxisY.LineColor = Color.Transparent;
            ca.AxisX.LineWidth = 0;
            ca.AxisY.LineWidth = 0;
            ca.AxisX.MajorTickMark.Enabled = false;
            ca.AxisY.MajorTickMark.Enabled = false;
            ca.AxisX.MinorTickMark.Enabled = false;
            ca.AxisY.MinorTickMark.Enabled = false;
            ca.AxisX.LabelStyle.Enabled = false;
            ca.AxisY.LabelStyle.Enabled = false;
            ca.AxisX.MajorGrid.Enabled = false;
            ca.AxisY.MajorGrid.Enabled = false;
            ca.AxisX.MinorGrid.Enabled = false;
            ca.AxisY.MinorGrid.Enabled = false;

            ca.InnerPlotPosition = new ElementPosition(0, 5, 100, 90);
            ca.AxisY.Minimum = min; ca.AxisY.Maximum = max;
            chart.ChartAreas.Add(ca);
            Series s = new Series("Data")
            {
                ChartType = SeriesChartType.Line,
                Color = color,
                BorderWidth = 2,
                ChartArea = "SparkArea"
            };
            chart.Series.Add(s);
        }

        // --- Metode lainnya (Serial, Data, CSV, dll.) ---
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e) { if (!serialPort.IsOpen) return; try { while (serialPort.BytesToRead > 0) { string data = serialPort.ReadLine().Trim(); if (!string.IsNullOrEmpty(data)) { this.BeginInvoke(new Action(() => ProcessSerialData(data))); } } } catch (Exception) { /* Abaikan */ } }
        private void ProcessSerialData(string data) { ParseAndStoreValue(data, "Nilai O2", 0); ParseAndStoreValue(data, "Nilai CO2", 1, true); ParseAndStoreValue(data, "Nilai PM", 2); ParseAndStoreValue(data, "Nilai CO", 3); lastReading.Timestamp = DateTime.Now; lastReading.O2 = currentValues[0]; lastReading.CO2 = currentValues[1]; lastReading.PM = currentValues[2]; lastReading.CO = currentValues[3]; historicalData.Add(lastReading); UpdateDashboardUI(); }
        private void ParseAndStoreValue(string data, string key, int index, bool handleLessThan400 = false) { if (data.Contains(key)) { string[] parts = data.Split(':'); if (parts.Length >= 2) { string valueStr = parts[1].Trim(); valueStr = System.Text.RegularExpressions.Regex.Match(valueStr, @"[0-9\.<]+").Value; if (handleLessThan400 && valueStr.Contains("<400")) { valueStr = "400"; } if (double.TryParse(valueStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double parsedValue)) { currentValues[index] = parsedValue; } } } }
        private void UpdateDashboardUI() { if (this.InvokeRequired) { this.BeginInvoke(new Action(UpdateDashboardUI)); return; } for (int i = 0; i < 4; i++) { string valueFormat = i == 0 ? "F1" : "F0"; string displayValue = currentValues[i].ToString(valueFormat, CultureInfo.InvariantCulture).Replace('.', ','); valueLabels[i].Text = $"{displayValue} {units[i]}"; Series s = sparklineCharts[i].Series["Data"]; s.Points.Add(currentValues[i]); while (s.Points.Count > MAX_SPARKLINE_POINTS) { s.Points.RemoveAt(0); } sparklineCharts[i].Invalidate(); } }
        private void LoadSerialPorts() { try { string[] ports = SerialPort.GetPortNames(); portComboBox.Items.Clear(); if (ports.Length > 0) { portComboBox.Items.AddRange(ports); portComboBox.SelectedIndex = 0; connectButton.Enabled = true; } else { portComboBox.Items.Add("No Ports"); portComboBox.SelectedIndex = 0; connectButton.Enabled = false; } } catch (Exception ex) { MessageBox.Show($"Error loading ports: {ex.Message}"); } }
        private void ToggleConnection() { if (serialPort.IsOpen) { try { serialPort.Close(); connectButton.Text = "Connect"; portComboBox.Enabled = true; connectButton.BackColor = accentColor; } catch (Exception ex) { MessageBox.Show($"Error closing port: {ex.Message}"); } } else { try { if (portComboBox.SelectedItem == null || portComboBox.SelectedItem.ToString() == "No Ports") { MessageBox.Show("Select a COM port."); return; } serialPort.PortName = portComboBox.SelectedItem.ToString(); serialPort.BaudRate = 9600; serialPort.Open(); connectButton.Text = "Disconnect"; portComboBox.Enabled = false; connectButton.BackColor = disconnectColor; historicalData.Clear(); } catch (Exception ex) { MessageBox.Show($"Error opening port: {ex.Message}"); } } }
        private void ExportToCsv() { if (historicalData.Count == 0) { MessageBox.Show("No data to save.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); return; } SaveFileDialog saveFileDialog = new SaveFileDialog { Filter = "CSV File (*.csv)|*.csv", Title = "Save Sensor Data", FileName = $"SensorData_{DateTime.Now:yyyyMMdd_HHmmss}.csv" }; if (saveFileDialog.ShowDialog() == DialogResult.OK) { try { StringBuilder csvContent = new StringBuilder(); csvContent.AppendLine("Timestamp,O2 (%),CO2 (PPM),PM (ug/m3),CO (PPM)"); foreach (var reading in historicalData) { csvContent.AppendLine($"{reading.Timestamp:yyyy-MM-dd HH:mm:ss},{reading.O2.ToString("F2", CultureInfo.InvariantCulture)},{reading.CO2.ToString("F0")},{reading.PM.ToString("F0")},{reading.CO.ToString("F0")}"); } File.WriteAllText(saveFileDialog.FileName, csvContent.ToString(), Encoding.UTF8); MessageBox.Show($"Data successfully saved to {saveFileDialog.FileName}", "Save Success", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch (Exception ex) { MessageBox.Show($"Error saving data: {ex.Message}", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error); } } }
        protected override void OnFormClosing(FormClosingEventArgs e) { if (serialPort != null && serialPort.IsOpen) { try { serialPort.Close(); } catch { } } base.OnFormClosing(e); }
    }
}